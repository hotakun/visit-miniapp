@echo off
cd /d "%~dp0"
set "EDGE="
if exist "%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe" set "EDGE=%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe"
if not defined EDGE if exist "%ProgramFiles%\Microsoft\Edge\Application\msedge.exe" set "EDGE=%ProgramFiles%\Microsoft\Edge\Application\msedge.exe"
if not defined EDGE if exist "%LocalAppData%\Google\Chrome\Application\chrome.exe" set "EDGE=%LocalAppData%\Google\Chrome\Application\chrome.exe"
set "HTML=%~dp0get-my-ip.html"
set "HTML=%HTML:\=/%"
if defined EDGE (
  start "" "%EDGE%" --app="file:///%HTML%" --window-size=460,500 --no-first-run --no-default-browser-check
) else (
  start "" "%~dp0get-my-ip.html"
)
